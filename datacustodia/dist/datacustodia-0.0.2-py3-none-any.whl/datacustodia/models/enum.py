BUCKET_NAME = "data-custodia"
DE_PARA_BUCKET_NAME = {
    "CSV": "sor-data-custodia",
    "SOR": "sor-data-custodia",
    "SOT": "sot-data-custodia",
    "SPEC": "spec-data-custodia"
}
CSV_LANDING_BUCKET = "landing-data-custodia"
PREFIX_ATIFACTS = "dataplatform/"
TABELA_IDEMPOTENCIA = "tb_cntr_psst"