BUCKET_NAME = "data-custodia"
DE_PARA_BUCKET_NAME = {
    "CSV": "data-custodia",
    "SOR": "sor-data-custodia",
    "SOT": "sot-data-custodia",
    "SPEC": "spec-data-custodia"
}
PREFIX_ATIFACTS = "dataplatform/"